-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Хост: localhost:8889
-- Время создания: Май 03 2025 г., 08:57
-- Версия сервера: 5.7.39
-- Версия PHP: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `personal_finance`
--

-- --------------------------------------------------------

--
-- Структура таблицы `account`
--

CREATE TABLE `account` (
  `id` bigint(20) NOT NULL,
  `amount` double DEFAULT NULL,
  `created` datetime(6) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `updated` datetime(6) DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `account_seq`
--

CREATE TABLE `account_seq` (
  `next_val` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `account_seq`
--

INSERT INTO `account_seq` (`next_val`) VALUES
(1);

-- --------------------------------------------------------

--
-- Структура таблицы `balance`
--

CREATE TABLE `balance` (
  `id` bigint(20) NOT NULL,
  `amount` double DEFAULT NULL,
  `comment` text,
  `created` datetime(6) DEFAULT NULL,
  `date` datetime(6) DEFAULT NULL,
  `inn` varchar(11) DEFAULT NULL,
  `parent_id` bigint(20) DEFAULT NULL,
  `phone` varchar(12) DEFAULT NULL,
  `recipient_account_number` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `updated` datetime(6) DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `account_id` bigint(20) DEFAULT NULL,
  `category_id` bigint(20) DEFAULT NULL,
  `person_type_id` bigint(20) DEFAULT NULL,
  `recipient_bank_id` bigint(20) DEFAULT NULL,
  `sender_bank_id` bigint(20) DEFAULT NULL,
  `transaction_status_id` bigint(20) DEFAULT NULL,
  `type_id` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `balance_seq`
--

CREATE TABLE `balance_seq` (
  `next_val` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `balance_seq`
--

INSERT INTO `balance_seq` (`next_val`) VALUES
(1);

-- --------------------------------------------------------

--
-- Структура таблицы `bank`
--

CREATE TABLE `bank` (
  `id` bigint(20) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `bank_seq`
--

CREATE TABLE `bank_seq` (
  `next_val` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `bank_seq`
--

INSERT INTO `bank_seq` (`next_val`) VALUES
(1);

-- --------------------------------------------------------

--
-- Структура таблицы `category`
--

CREATE TABLE `category` (
  `id` bigint(20) NOT NULL,
  `allamount` double DEFAULT NULL,
  `budget` double DEFAULT NULL,
  `created` datetime(6) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `type_id` tinyint(4) DEFAULT NULL,
  `updated` datetime(6) DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `category_seq`
--

CREATE TABLE `category_seq` (
  `next_val` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `category_seq`
--

INSERT INTO `category_seq` (`next_val`) VALUES
(1);

-- --------------------------------------------------------

--
-- Структура таблицы `person_type`
--

CREATE TABLE `person_type` (
  `id` bigint(20) NOT NULL,
  `created` datetime(6) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `updated` datetime(6) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `person_type`
--

INSERT INTO `person_type` (`id`, `created`, `title`, `updated`) VALUES
(1, NULL, 'Физическое лицо', NULL),
(2, NULL, 'Юридическое лицо', NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `person_type_seq`
--

CREATE TABLE `person_type_seq` (
  `next_val` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `person_type_seq`
--

INSERT INTO `person_type_seq` (`next_val`) VALUES
(101);

-- --------------------------------------------------------

--
-- Структура таблицы `transaction_status`
--

CREATE TABLE `transaction_status` (
  `id` bigint(20) NOT NULL,
  `title` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `transaction_status`
--

INSERT INTO `transaction_status` (`id`, `title`) VALUES
(3, 'В обработке'),
(7, 'Возврат'),
(1, 'Новая'),
(4, 'Отменена'),
(5, 'Платеж выполнен'),
(6, 'Платеж удален'),
(2, 'Подтвержденная');

-- --------------------------------------------------------

--
-- Структура таблицы `type`
--

CREATE TABLE `type` (
  `id` bigint(20) NOT NULL,
  `created` datetime(6) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `updated` datetime(6) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `type`
--

INSERT INTO `type` (`id`, `created`, `title`, `updated`) VALUES
(1, NULL, 'Доход', NULL),
(2, NULL, 'Расход', NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `type_seq`
--

CREATE TABLE `type_seq` (
  `next_val` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `type_seq`
--

INSERT INTO `type_seq` (`next_val`) VALUES
(101);

-- --------------------------------------------------------

--
-- Структура таблицы `user`
--

CREATE TABLE `user` (
  `id` bigint(20) NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `role` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `account`
--
ALTER TABLE `account`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `balance`
--
ALTER TABLE `balance`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FKxhe1wv9gspc3wl0w66bptmgs` (`account_id`),
  ADD KEY `FKatg7dj4isarx48w23at3na3yf` (`category_id`),
  ADD KEY `FKs1noydao8hrk37gu35h3hupm4` (`person_type_id`),
  ADD KEY `FKt0xo6ufd2y8dboyonh47yprt1` (`recipient_bank_id`),
  ADD KEY `FK8rc1h6wg134w98exh71dkddl5` (`sender_bank_id`),
  ADD KEY `FK1plj1dvd0gmep5qhvq7556ury` (`transaction_status_id`),
  ADD KEY `FKdjuc6qbcxrs6ftn7mq2ha6bqn` (`type_id`);

--
-- Индексы таблицы `bank`
--
ALTER TABLE `bank`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `person_type`
--
ALTER TABLE `person_type`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `transaction_status`
--
ALTER TABLE `transaction_status`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UK1lnfkma296mb1m8rbqin4mmov` (`title`);

--
-- Индексы таблицы `type`
--
ALTER TABLE `type`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `transaction_status`
--
ALTER TABLE `transaction_status`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT для таблицы `user`
--
ALTER TABLE `user`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `balance`
--
ALTER TABLE `balance`
  ADD CONSTRAINT `FK1plj1dvd0gmep5qhvq7556ury` FOREIGN KEY (`transaction_status_id`) REFERENCES `transaction_status` (`id`),
  ADD CONSTRAINT `FK8rc1h6wg134w98exh71dkddl5` FOREIGN KEY (`sender_bank_id`) REFERENCES `bank` (`id`),
  ADD CONSTRAINT `FKatg7dj4isarx48w23at3na3yf` FOREIGN KEY (`category_id`) REFERENCES `category` (`id`),
  ADD CONSTRAINT `FKdjuc6qbcxrs6ftn7mq2ha6bqn` FOREIGN KEY (`type_id`) REFERENCES `type` (`id`),
  ADD CONSTRAINT `FKs1noydao8hrk37gu35h3hupm4` FOREIGN KEY (`person_type_id`) REFERENCES `person_type` (`id`),
  ADD CONSTRAINT `FKt0xo6ufd2y8dboyonh47yprt1` FOREIGN KEY (`recipient_bank_id`) REFERENCES `bank` (`id`),
  ADD CONSTRAINT `FKxhe1wv9gspc3wl0w66bptmgs` FOREIGN KEY (`account_id`) REFERENCES `account` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
